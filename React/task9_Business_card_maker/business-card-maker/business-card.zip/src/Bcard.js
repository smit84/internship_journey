import React, { useState } from 'react'
import Display from './components/Display'
import Wizard from './components/Wizard'
import './styles/Bcard.css'

export default function Bcard() {
  const [template, setTemplate] = useState("clean");
  const [theme,setTheme] = useState("Main");
  const [companyName, setCompanyName] = useState("");
  const [logo, setLogo] = useState("");
  const [website, setWebsite] = useState("");
  const [fullName, setFullName] = useState("");
  const [designation, setDesignation] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [emailAddress, setEmailAddress] = useState("");

  const handleTemplate = (event) => {
    const value = event.target.value;
    setTemplate(value);
  }
  const handleTheme = (event) => {
    const value = event.target.value;
    setTheme(value);
  }
  const handleCompanyName = (event) => {
    const value = event.target.value;
    setCompanyName(value);
  }
  const handleLogo = (event) => {
    const value = event.target.value;
    setLogo(value);
  }
  const handleWebsite = (event) => {
    const value = event.target.value;
    setWebsite(value);
  }
  const handleFullName = (event) => {
    const value = event.target.value;
    setFullName(value);
  }
  const handleDesignation = (event) => {
    const value = event.target.value;
    setDesignation(value);
  }
  const handleContactNumber = (event) => {
    const value = event.target.value;
    setContactNumber(value);
  }
  const handleEmailAddress = (event) => {
    const value = event.target.value;
    setEmailAddress(value);
  }


  return (
    <div className='BusinessCard'>
      <div className='WizardWrapper'>
        <Wizard/>
      </div>
      <div className='DisplayWrapper'>
        <Display/>
      </div>
    </div>
  )
}

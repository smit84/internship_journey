import Bcard from "./Bcard";
import './styles/App.css';

function App() {
  return (
    <div className="App">
      <div className="Title">
        <h1>create your business card</h1>
      </div>
      <div className="BcardWrapper">
        <Bcard/>
      </div>
    </div>
  );
}

export default App;

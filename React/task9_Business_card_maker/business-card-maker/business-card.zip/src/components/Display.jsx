import React from 'react'
import '../styles/Display.css'

export default function Display() {
  return (
    <div className='Display'>
         <div className='DisplayCardFront'>
            <div className='LeftCard'>
                <img alt='Compony logo'/>
                <h3>Company Name</h3>  
            </div>
            <hr/>
            <div className='RightCard'>
                <h4 className='FullName'>Full Name</h4>
                <h5 className='Designation'>Designation</h5>
                <h6 className='PhoneNo'>Phone Number</h6>
                <h6 className='Email'>Email</h6>
                <h6 className='Website'>Website</h6>
            </div>
        </div> 
        <div className='DisplayCardBack'></div>
        
        

    </div>
  )
}

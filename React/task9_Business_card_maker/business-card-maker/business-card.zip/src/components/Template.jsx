import React from 'react'

export default function Template() {
   
  return (
    <div className='Template'>
    
        <select  className="form-select">
            <option defaultValue disabled>
            Select Template
            </option>
            <option value="Clean">Clean</option>
            <option value="Standard">Standard</option>
            
        </select>
            
    </div>
  )
}

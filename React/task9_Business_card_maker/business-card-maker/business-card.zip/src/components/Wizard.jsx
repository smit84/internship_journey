import React, { useEffect, useState } from 'react'
import Personalization from './Personalization';
import Template from './Template'
import Theme from './Theme'
import '../styles/Wizard.css'

export default function Wizard() {
    const[page,setPage]= useState(0);
    
    
    const showLevel = () => {
        switch (page) {
          case 0:
            return <Template />;
          case 1:
            return <Theme />;
           case 2:
             return <Personalization />;
           default:
             return <Template />;
        }
      }; 
  return (
    <div className='Wizard'>
        <form>
            {showLevel()}

        </form>
        <button onClick={() =>setPage(prev =>prev+1) }>next</button>
        
        
        {
        page > 0 && <button onClick={() => setPage(prev => prev-1)}>Prev</button>
        }   
    </div>
  )
}

import React, { useState } from 'react'

export default function Theme() {
    const [themes,setTheme] = useState(['Light','Main','Dark']);
    const handleTheme = () =>{

    }
  return (
    <div >
        <select onChange={handleTheme()}>
            <option>Choose Template</option>
                {themes.map((theme, index) => {
                return <option key={index} >
                {theme}
            </option>
            })}
        </select>

    </div>
    
  )
}

import React from 'react'

export default function Input({label,type ,name}) {
  return (
    <label>{label} :
    <input type={type} name={name} />
  </label>
  )
}

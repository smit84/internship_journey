import React from 'react'
import Input from './Input'
import '../styles/Personalization.css'

export default function Personalization() {
  return (
    <div className='wizard-page'>
        <Input 
        label = "Company Name"
        type="text"
        name = "companyName"/>
        <Input 
        label = "Company Name"
        type="text"
        name = "companyName"/>
        <Input 
        label = "Company Name"
        type="text"
        name = "companyName"/>
        <Input 
        label = "Company Name"
        type="text"
        name = "companyName"/>
        <Input 
        label = "Company Name"
        type="text"
        name = "companyName"/>

    </div>
  )
}
